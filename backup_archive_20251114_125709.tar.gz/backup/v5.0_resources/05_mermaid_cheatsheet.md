# Mermaid 다이어그램 빠른 참고

## 흐름도
```mermaid
flowchart LR
  A[주제] --> B[핵심 질문]
  B --> C[자료 조사]
  C --> D[분석]
  D --> E[결론]
```

## 순서도
```mermaid
sequenceDiagram
  participant S as 학생
  participant AI as AI 도구
  S->>AI: 요청(스펙+컨텍스트)
  AI-->>S: 작업 목록 제안
  S-->>AI: 결과 검토/수정
```

## 간트
```mermaid
gantt
    title 샘플 일정
    dateFormat  YYYY-MM-DD
    준비 :done, 2025-10-20, 2025-10-22
    조사 :active, 2025-10-23, 2025-10-26
```

## 그래프(관계)
```mermaid
graph TD
  R[논문] --> K[핵심 개념]
  R --> M[방법]
  K --> Q[연구 질문]
```

<!-- [강사 노트] 코드블록 그대로 복사-붙여넣기하면서 도형만 살짝 바꾸는 실습 유도. -->