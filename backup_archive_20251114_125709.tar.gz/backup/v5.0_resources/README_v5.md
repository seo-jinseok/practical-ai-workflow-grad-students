# v5.0 리소스 모음 (대학원 신입생 실습용)

**목적**
- 2시간 강의에 맞춰 바로 사용할 수 있는 실습/참고 자료 제공
- 각 파일은 슬라이드에 연결되어 있으며, 복사-붙여넣기 또는 직접 편집 가능

**구성(번호=강의 순서)**
- 01_lecture_agenda.md — 2시간 진행표(요약)
- 02_spec_template.md — 스펙(요구사항) 템플릿
- 03_context_pack_template.md — 컨텍스트 패키지 템플릿
- 04_planning_checklist.md — 체크리스트/칸반/간트 가이드
- 05_mermaid_cheatsheet.md — Mermaid 다이어그램 예시 모음
- 06_hands_on_exercises_v5.md — 실습 안내(스펙/컨텍스트/플래닝)
- 07_demo_script_v5.md — 데모 진행 스크립트(강사용)
- 08_sample_research_notes_v5.md — 샘플 연구 노트
- 09_prompt_collection_v5.md — 초보 친화 프롬프트 모음
- 10_tools_comparison_2025.md — 도구 비교(범주형, 브랜드 최소)
- 11_rag_graph_guidelines.md — RAG/GraphRAG 초보 가이드
- 12_eval_template_v5.md — 평가/검증 체크리스트
- 13_google_slides_import_guide.md — Google Slides 삽입 팁

**빠른 시작**
- 스펙/컨텍스트 템플릿(02, 03)을 본인 주제로 채우세요.
- 04의 체크리스트로 오늘 할 일 3개만 정하고, 칸반 3열로 관리.
- 05의 Mermaid 예시를 복사해 슬라이드에 붙여 넣어 시각화.

<!-- [강사 노트] 강의 도중에는 02/03/04/05/06만 바로 열어 실습 유도. -->