# 검증 코멘트 구현 TODO 목록

## 작업 개요
13개의 검증 코멘트를 순차적으로 구현하여 코드베이스의 품질과 일관성을 향상시킵니다.

## 완료된 작업
- [x] TODO 목록 생성

## 구현할 작업들

### Comment 1: MCP 서버 명칭 혼용 문제 해결
- [x] `.specify/memory/constitution.md` - `task-master-ai MCP` → `task-master-mcp` 교체
- [x] `Practical_AI_Workflow_for_Grad_Students_Part2.md` - JSON 예제에서 `mcpServers` 키를 `task-master-mcp`로 설정
- [x] `resources/part2/15_mcp_installation_guide.md` - JSON 설정 업데이트 완료
- [x] `Context_and_Planning/demo-files/06-mcp-installation/installation-script.md` - MCP 서버 명칭 통일 완료
- [x] `Context_and_Planning/demo-files/06-mcp-installation/config-completed.json` - JSON 키 업데이트 완료
- [x] `Context_and_Planning/demo-files/06-mcp-installation/config-template.json` - JSON 키 업데이트 완료
- [x] `Context_and_Planning/demo-files/06-mcp-installation/test-prompts.md` - 텍스트 업데이트 완료
- [x] `Context_and_Planning/README.md` - MCP 서버 명칭 통일 완료
- [x] `Context_and_Planning/tool-demonstration-plan.md` - MCP 서버 명칭 통일 완료
- [x] `Context_and_Planning/lecture-structure.md` - MCP 서버 명칭 통일 완료
- [x] `Context_and_Planning/content-flow.md` - MCP 서버 명칭 통일 완료
- [ ] 전체 repo-wide grep으로 잔여 `task-master-ai MCP` 구문 제거 확인 (49개 잔여)

### Comment 2: 중국어(한자) 혼입 문제 해결
- [x] `resources/README.md` - `导航` → `내비게이션`, `研究者용` → `연구자용` 교체 완료
- [x] `v13.0_RELEASE_CHECKLIST.md` - `应急` → `비상`, `过时된` → `구식`/`오래된` 교체 완료
- [ ] 전체 repo에서 추가 CJK 문자 검색 및 한국어 용어로 수정 (이후 단계에서 수행)

### Comment 3: 스크린샷 캡처 가이드 파일 생성
- [x] `resources/part2/12_screenshot_descriptions.md` - Part 2 스크린샷 캡처 가이드 파일 생성 완료
- [x] `resources/part3/24-37_screenshot_descriptions.md` - Part 3 스크린샷 캡처 가이드 파일 생성 완료
- [x] Part 2, Part 3, README.md에 크로스링크 추가 (각 파일 내 관련 문서 섹션 포함)

### Comment 4: Dead Link 문제 해결
- [x] `resources/README.md` - TBD 파일 24번을 스크린샷 가이드로 변경, 27-29번을 "생성 예정"으로 상태 업데이트 완료
- [x] v5.0_resources 디렉토리 확인 완료 - 실제로 존재하고 README_v5.md 있음, 유효한 링크임
- [x] Dead Link 문제 해결 완료 - 참조가 유효하거나 명확한 상태로 변경됨

### Comment 5: copilot-instructions.md 최신성 개선
- [ ] `.github/copilot-instructions.md` - Tool References 섹션 추가 (GPT-5, Claude Sonnet 4.5, Gemini 2.5 Pro, Grok Code Fast 1)
- [ ] "2025-11-10 기준" 날짜 추가
- [ ] Project Goals에 예체능 학과 추가
- [ ] Version 섹션 추가 (Current: v13.0, Constitution: v1.1.2)

### Comment 6: Part 2 섹션 교차참조 검증
- [ ] `Practical_AI_Workflow_for_Grad_Students_Part2.md` - 모든 섹션 참조 교차검증
- [ ] "Section 3.2"等形式의 참조 오류 수정
- [ ] 앵커 링크와 생성된 ID 일치성 확인
- [ ] TOC 엔트리 업데이트

### Comment 7: 외부 링크 검증
- [ ] 모든 Markdown 파일에서 링크 체크 실행
- [ ] 주요 URL 수동 테스트: GitHub Copilot Plans, Education Pack, VS Code, Claude Desktop, MCP site, SpecKit repo/docs, 연구도구들
- [ ] 리다이렉트 또는 변경된 URL 업데이트

### Comment 8: SpecKit 링크 오타 수정
- [ ] `Practical_AI_Workflow_for_Grad_Students_Part2.md` - `https://github.github.com/spec-kit/` → `https://github.com/github/spec-kit`
- [ ] `resources/21_speckit_practice_project.md` - SpecKit 데모 파일 경로 확인
- [ ] 전체 resources에서 SpecKit 링크 일관성 확인

### Comment 9: 예체능 사례 보강
- [ ] `resources/part2/12_copilot_workbook_exercises.md` - 예체능 예제 추가 (Exercise 3 또는 4)
- [ ] 비코딩 대안(SPSS/Sheets) 및 전공별 프롬프트 포함
- [ ] `resources/README.md` - 학과별 경로 업데이트

### Comment 10: JSON/명령어 설명 보강
- [ ] `resources/part2/15_mcp_installation_guide.md` - 코드블록 앞에 한국어 설명 추가
- [ ] `Practical_AI_Workflow_for_Grad_Students_Part2.md` - JSON 기본 개념 설명 추가
- [ ] `Context_and_Planning/demo-files/07-speckit-practice/terminal-commands.md` - 명령어 목적 및 예상 출력 설명

### Comment 11: 외부 도구 버전 정보 추가
- [ ] `resources/README.md` - 버전 테이블 추가 (2025-11-10 기준)
- [ ] 또는 각 Part footer에 버전 정보 추가
- [ ] Copilot tiers, SpecKit v0.0.79+, MCP registry, 모델명 포함

### Comment 12: AGENTS.md와 copilot-instructions.md 일치성
- [ ] `.github/copilot-instructions.md` - AGENTS.md와 내용 정렬
- [ ] 날짜 기준(2025-11-10) 및 모델 세트 일치 확인
- [ ] 양 파일에 공동 업데이트 요구사항 및 버전/날짜 푸터 추가

### Comment 13: 데모 파일 경로 검증
- [ ] `Context_and_Planning/demo-files/` - 모든 참조 파일 존재 확인 (대소문자 구분)
- [ ] `resources/README.md` 및 리소스 크로스링크 업데이트
- [ ] 데모 파일 참조 링크체크 단계 QA 체크리스트에 추가

## 최종 검증
- [ ] 전체 변경사항 검토 및 테스트
- [ ] 링크有效性 재검증
- [ ] 문서 일관성 최종 확인
