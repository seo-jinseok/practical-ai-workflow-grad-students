# 대학원생 문제 상황 다이어그램

## 버전 1: Mindmap 스타일

```mermaid
mindmap
  root((😰 문제 상황들))
    📁 파일 관리 혼란
      논문_최종.docx, 논문_진짜최종.docx, 논문_진짜진짜최종.docx
      어디에 뭘 저장했는지 기억 안 남
      중요한 자료를 찾을 수 없음
    🤔 연구 방향 혼란
      처음 계획과 다른 방향으로 흘러감
      왜 이 연구를 시작했는지 잊어버림
      지도교수님께 진행상황 설명하기 어려움
    ⏰ 시간 관리 실패
      마감일이 다가와서야 급하게 시작
      어떤 일을 먼저 해야 할지 모름
      같은 작업을 반복해서 시간 낭비
```

## 버전 2: Flowchart 스타일 (권장)

```mermaid
flowchart TD
    A[😰 문제 상황들] --> B[📁 파일 관리 혼란]
    A --> C[🤔 연구 방향 혼란]
    A --> D[⏰ 시간 관리 실패]
    
    B --> B1["논문_최종.docx<br/>논문_진짜최종.docx<br/>논문_진짜진짜최종.docx"]
    B --> B2[어디에 뭘 저장했는지<br/>기억 안 남]
    B --> B3[중요한 자료를<br/>찾을 수 없음]
    
    C --> C1[처음 계획과 다른<br/>방향으로 흘러감]
    C --> C2[왜 이 연구를 시작했는지<br/>잊어버림]
    C --> C3[지도교수님께 진행상황<br/>설명하기 어려움]
    
    D --> D1[마감일이 다가와서야<br/>급하게 시작]
    D --> D2[어떤 일을 먼저<br/>해야 할지 모름]
    D --> D3[같은 작업을 반복해서<br/>시간 낭비]
    
    classDef problemCategory fill:#ffcccc,stroke:#ff6666,stroke-width:2px
    classDef subProblem fill:#fff2cc,stroke:#d6b656,stroke-width:1px
    
    class B,C,D problemCategory
    class B1,B2,B3,C1,C2,C3,D1,D2,D3 subProblem
```

## 버전 3: 간단한 Tree 구조

```mermaid
graph TD
    Root["😰 문제 상황들"]
    
    Root --- File["📁 파일 관리 혼란"]
    Root --- Research["🤔 연구 방향 혼란"]
    Root --- Time["⏰ 시간 관리 실패"]
    
    File --- F1["논문_최종.docx, 논문_진짜최종.docx,<br/>논문_진짜진짜최종.docx"]
    File --- F2["어디에 뭘 저장했는지 기억 안 남"]
    File --- F3["중요한 자료를 찾을 수 없음"]
    
    Research --- R1["처음 계획과 다른 방향으로 흘러감"]
    Research --- R2["왜 이 연구를 시작했는지 잊어버림"]
    Research --- R3["지도교수님께 진행상황 설명하기 어려움"]
    
    Time --- T1["마감일이 다가와서야 급하게 시작"]
    Time --- T2["어떤 일을 먼저 해야 할지 모름"]
    Time --- T3["같은 작업을 반복해서 시간 낭비"]
    
    style Root fill:#ff9999,stroke:#333,stroke-width:3px
    style File fill:#ffcccc,stroke:#666,stroke-width:2px
    style Research fill:#ffcccc,stroke:#666,stroke-width:2px
    style Time fill:#ffcccc,stroke:#666,stroke-width:2px
```