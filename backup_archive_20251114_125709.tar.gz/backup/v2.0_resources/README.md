# 생성형 AI 기반 연구 생산성 향상 워크플로우 v2.0 - 리소스 가이드

## 📁 폴더 구성

이 폴더에는 "Practical_AI_Workflow_for_Grad_Students v2.0.md" 강의를 위한 모든 지원 자료가 포함되어 있습니다.

### 📋 파일 목록

| 파일명 | 용도 | 대상 |
|--------|------|------|
| `sample_research_notes.md` | 시연용 연구 노트 샘플 | 강사, 학생 |
| `ai_prompts_collection.md` | 연구 단계별 AI 프롬프트 모음 | 학생, 실습용 |
| `demonstration_script.md` | 실시간 시연 가이드 | 강사 전용 |
| `ai_tools_comparison.md` | AI 도구 비교 및 선택 가이드 | 학생, 참고용 |
| `hands_on_exercises.md` | 단계별 실습 과제 | 학생, 과제용 |
| `README.md` | 이 파일 - 전체 가이드 | 모든 사용자 |

---

## 🎯 사용 목적별 가이드

### 👨‍🏫 강사용 가이드

**강의 준비 체크리스트**
- [ ] `demonstration_script.md` 숙지 및 시연 환경 준비
- [ ] 모든 AI 도구 계정 로그인 상태 확인
- [ ] `sample_research_notes.md`를 시연용으로 준비
- [ ] 백업 시연 자료 (스크린샷, 동영상) 준비

**강의 진행 순서**
1. 메인 프레젠테이션 (`v2.0.md`) 진행
2. `demonstration_script.md` 따라 실시간 시연
3. `hands_on_exercises.md`에서 적절한 실습 선택
4. `ai_prompts_collection.md` 참고하여 질의응답

### 👩‍🎓 학생용 가이드

**학습 단계별 활용법**

**1단계: 기본 이해**
- 메인 프레젠테이션 내용 숙지
- `ai_tools_comparison.md`로 도구 특성 파악

**2단계: 실습 준비**
- `sample_research_notes.md` 구조 분석
- `ai_prompts_collection.md`에서 관련 프롬프트 선택

**3단계: 실제 적용**
- `hands_on_exercises.md`의 실습 과제 수행
- 개인 연구 주제에 맞게 프롬프트 수정

**4단계: 심화 학습**
- 다양한 AI 도구 조합 실험
- 개인 맞춤형 워크플로우 개발

---

## 🛠️ 기술적 요구사항

### 필수 도구
- **웹 브라우저**: Chrome, Firefox, Safari 등 (최신 버전)
- **텍스트 에디터**: VS Code (권장) 또는 기타 마크다운 지원 에디터
- **인터넷 연결**: 안정적인 고속 인터넷

### AI 도구 계정 (우선순위별)
1. **필수**: ChatGPT (무료 또는 Plus), Claude (무료 또는 Pro)
2. **권장**: Elicit (무료), Research Rabbit (무료)
3. **선택**: Perplexity Pro, GitHub Copilot (학생 무료)

### 설치 권장 소프트웨어
- **Zotero**: 참고문헌 관리 (무료)
- **VS Code**: 통합 개발 환경 (무료)
- **GitHub Copilot**: AI 코딩 어시스턴트 (학생 무료)

---

## 📚 학습 로드맵

### 🥉 초급 단계 (1-2주)
**목표**: AI 도구 기본 사용법 익히기

**학습 내용**:
- ChatGPT/Claude 기본 프롬프트 작성
- 마크다운 문법 익히기
- Zotero 기본 사용법

**실습 과제**:
- `hands_on_exercises.md`의 실습 1-2 완료
- 개인 연구 주제로 간단한 문헌 검색

### 🥈 중급 단계 (3-4주)
**목표**: 전문 AI 도구 활용 및 워크플로우 구축

**학습 내용**:
- Elicit, Research Rabbit 활용법
- VS Code + Copilot 기본 사용
- 도구 간 연동 방법

**실습 과제**:
- `hands_on_exercises.md`의 실습 3-4 완료
- 실제 연구 프로젝트에 적용

### 🥇 고급 단계 (5-6주)
**목표**: 완전한 AI 기반 연구 워크플로우 마스터

**학습 내용**:
- OpenAI o1 고급 활용
- 복잡한 연구 설계 자동화
- AI 윤리 및 품질 관리

**실습 과제**:
- `hands_on_exercises.md`의 실습 5 및 보너스 완료
- 개인 맞춤형 워크플로우 개발

---

## 🔧 문제 해결 가이드

### 자주 발생하는 문제들

**Q1: AI 도구 접속이 안 됩니다**
- 인터넷 연결 상태 확인
- VPN 사용 시 해제 후 재시도
- 브라우저 캐시 및 쿠키 삭제

**Q2: 프롬프트 결과가 만족스럽지 않습니다**
- `ai_prompts_collection.md`의 예시 참고
- 더 구체적이고 명확한 지시사항 추가
- 맥락 정보를 충분히 제공

**Q3: 도구 간 연동이 잘 안 됩니다**
- 표준 파일 형식 (BibTeX, CSV) 활용
- 수동 복사-붙여넣기로 임시 해결
- 각 도구의 내보내기/가져오기 기능 확인

**Q4: 비용 부담이 큽니다**
- 무료 도구 우선 활용 (`ai_tools_comparison.md` 참고)
- 학생 할인 혜택 적극 활용
- 팀 단위 구독으로 비용 분담

---

## 📖 추가 학습 자료

### 온라인 리소스
- **공식 문서**: 각 AI 도구의 Help Center 및 Documentation
- **YouTube**: "AI for Research", "Academic Writing with AI" 검색
- **블로그**: Elicit Blog, OpenAI Blog, Anthropic Blog

### 커뮤니티
- **Reddit**: r/AcademicWriting, r/GradSchool, r/MachineLearning
- **Discord**: AI for Research 서버
- **Facebook**: AI Tools for Researchers 그룹

### 뉴스레터
- **The Batch** (deeplearning.ai): AI 업계 동향
- **AI Research Tools Weekly**: 연구용 AI 도구 소식
- **Import AI**: AI 기술 발전 소식

---

## 🤝 기여 및 피드백

### 피드백 방법
- 강의 후 설문조사 참여
- 이메일을 통한 개별 피드백
- 온라인 커뮤니티에서 경험 공유

### 개선 제안
- 새로운 AI 도구 추천
- 실습 과제 개선 아이디어
- 추가 리소스 제안

### 업데이트 계획
- **월간**: 새로운 AI 도구 및 기능 반영
- **분기별**: 실습 과제 및 프롬프트 개선
- **연간**: 전체 커리큘럼 개편

---

## 📞 지원 및 문의

### 기술적 지원
- 강의 중 실시간 질의응답
- 강의 후 개별 상담 (예약제)
- 온라인 포럼을 통한 커뮤니티 지원

### 학습 지원
- 정기 워크샵 및 세미나
- 스터디 그룹 구성 지원
- 멘토링 프로그램 연결

---

## 📄 라이선스 및 사용 조건

### 사용 허가
- 교육 목적의 자유로운 사용 및 수정 허가
- 상업적 사용 시 사전 승인 필요
- 출처 표기 필수

### 면책 조항
- AI 도구 사용 결과에 대한 책임은 사용자에게 있음
- 도구별 이용약관 및 개인정보 처리방침 준수 필요
- 학술 윤리 및 연구 윤리 준수 의무

---

**마지막 업데이트**: 2024년 10월 28일  
**버전**: v2.0  
**문의**: [강사 연락처]

---

*이 리소스가 여러분의 연구 여정에 도움이 되기를 바랍니다. AI와 함께하는 새로운 연구의 시대를 열어가세요! 🚀*
