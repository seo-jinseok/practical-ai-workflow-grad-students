# Part 2 리소스 파일 구현 체크리스트

## 작업 개요
- [ ] Comment 1: 계획된 Part 2 리소스 파일 4개 생성
- [ ] Comment 2: 메인 Part 2 문서에 교차 링크 추가
- [ ] Comment 3: Part 2 전용 폴더 구조 개선
- [ ] Comment 4: 임시 부록 추가

## 세부 작업 목록

### 1단계: Part 2 리소스 파일 생성
- [ ] README_Part2.md 생성 (Part 2 전용 README)
- [ ] 12_copilot_workbook_exercises.md 생성 (GitHub Copilot 워크북)
- [ ] 15_mcp_installation_guide.md 생성 (MCP 설치 가이드)
- [ ] 19_speckit_installation_guide.md 생성 (SpecKit 설치 가이드)

### 2단계: 교차 링크 추가
- [ ] 메인 Part 2 문서 섹션별 리소스 파일 링크 추가
- [ ] Section 2 끝에 Copilot 워크북 링크 추가
- [ ] Section 4 끝에 MCP 설치 가이드 링크 추가
- [ ] Section 5 끝에 SpecKit 설치 가이드 링크 추가
- [ ] 문서 말미에 Part 2 README 링크 추가

### 3단계: 폴더 구조 개선
- [ ] part2/ 하위 폴더 생성 검토
- [ ] Part 2 전용 파일들의 논리적 그룹핑
- [ ] README_Part2.md에서 전체 Part 2 인덱스 제공

### 4단계: 임시 부록 추가
- [ ] 부록 A: Copilot 워크북 축약본 추가
- [ ] 핵심 단계와 체크리스트 자체 포함하도록 보강
- [ ] 향후 리소스 파일 링크로 대체할 준비

### 5단계: 검증 및 완료 처리
- [ ] 생성된 파일들의 존재 검증
- [ ] todo_list.md의 해당 항목들 완료 처리
- [ ] 전체 Part 2 구조 최종 확인
