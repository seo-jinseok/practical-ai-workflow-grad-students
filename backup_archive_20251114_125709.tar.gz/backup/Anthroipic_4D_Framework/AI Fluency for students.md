# AI Fluency for students

## Course Overview

- Introduction and AI Fluency Framework
  - Welcome to AI Fluency for students
  - AI Fluency Framework
- AI Fluency Framework applications for students
  - AI as a learning partner
  - AI in career planning
- Conclusion & certificate
  - Being the human in the loop
- Certificate of completion

## (Introduction and AI Fluency Framework)Welcome to AI Fluency for students

Estimated time: 5 minutes

### What you'll learn

By the end of this lesson you'll be able to:

- Understand the content that this course covers
- Explain why AI Fluency is an essential skill for students

### Welcome to AI Fluency for students

This video introduces the concept of AI Fluency—using AI effectively, efficiently, ethically, and safely, as well as what you'll learn in our AI Fluency for Students course. Rather than focusing on temporary tips or specific tools, the course explores enduring principles that help you make thoughtful decisions about when and how to use AI. The video outlines the course structure: starting with the 4D Framework, then exploring AI as a learning partner and career planning tool, and finally discussing what it means to be "the human in the loop." The goal is to transform AI from a tool that does work for you into a partner that helps you do your work better.

#### Video (AI Fluency for students: Introduction / teaser)

Hello and welcome to AI Fluency for Students.
In this course we’ll explore a different way of thinking about AI as a student – not quick tips or tricks or prompts, but Fluent AI use. So that your interactions with AI can be effective, efficient, ethical and safe.
Most guidance about AI focuses on use-cases that grow outdated when new models and products are introduced. But over the past few years we’ve observed one thing that perseveres — AI Fluency.  It goes beyond the models, beyond the tools, beyond the prompts, and asks some really important questions about what it means to use AI in our lives and work. How do we decide what to automate to AI? And what not to? How do we pick the right tools? And assess for accuracy? Do we tell our teachers or employers when we’ve used AI? And if so, how?
In this course, we’ll explore all of these questions and more.
Well start with an overview of the 4D framework—Delegation, Description, Discernment, and Diligence—four competencies that, when combined, create AI Fluency. These transform AI from a tool that does work for you into a partner that helps you do your work better.
Then, we’ll explore two practical applications of AI as a student:
You’ll learn how to bring AI into your learning in order understand concepts more deeply, as well as how to leverage AI in your career planning and job search — to brainstorm future career paths, develop skills, and land a great role.
Finally, we’ll talk about what it means to be the human in the loop. AI is becoming part of almost every aspect of our lives—from how we learn and work, to how we communicate and analyze problems.
The leaders of tomorrow (that’s you) are those who can work thoughtfully and responsibly with these systems.
By the end of this course, you'll have the confidence and skills to work with AI in ways that align with your values, enhance your learning, and prepares you for a future where AI fluency is essential.
Ready to get started? Let's dive in.

#### Key takeaways

- AI Fluency goes beyond prompts and tools to focus on enduring principles
- The course covers the 4D Framework, learning applications, and career planning
- Being fluent means making thoughtful decisions about what to automate and what not to
- The goal is to prepare you for a future where AI fluency is essential

### What's next

- Feedback
    As you progress through the course, we'd love to hear from you about how you are using concepts from the course in your life, work, or classes and any feedback you may have. Share your feedback here.

- Acknowledgments and license
    Copyright 2025 Rick Dakan, Joseph Feller, and Anthropic. Released under the CC BY-NC-SA 4.0 license. This course is based on The AI Fluency Framework by Dakan and Feller.Supported in part by the Higher Education Authority, Ireland, through the National Forum for the Enhancement of Teaching and Learning.

---

## (Introduction and AI Fluency Framework)AI Fluency Framework

Estimated time: 30 minutes

### What you'll learn

By the end of this lesson you'll be able to:

- Define AI Fluency means and explain why it matters for your academic and professional future
- Apply the 4D Framework (Delegation, Description, Discernment, Diligence) to your AI interactions
- Recognize the difference between using AI for automation versus augmentation
- Create a personal learning context document to guide future AI collaborations

### The 4Ds - Understanding the AI Fluency Framework

This comprehensive video introduces the 4D Framework—Delegation, Description, Discernment, and Diligence—as the foundation of AI fluency. It emphasizes that AI fluency is about augmentation (adding to your work) rather than automation (having AI do work for you), which is especially important in learning contexts. The video explores each D in detail: Delegation involves problem awareness, platform awareness, and task delegation; Description covers product, process, and performance aspects of communication; Discernment examines critical evaluation at all three levels; and Diligence ensures responsible, transparent, and accountable AI use. The video highlights how Description and Discernment work together in a continuous feedback loop, transforming AI from a tool into a thinking partner.

This video is just an introduction to the framework, for the full breakdown and many practical exercises, check out our AI Fluency: Framework & Foundations course here(https://anthropic.skilljar.com/ai-fluency-framework-foundations).

#### Video (The 4Ds: A Summary of the AI Fluency Framework)
 
You’ve probably tried AI — maybe to help with an essay, solve a problem, or just explore what it can do. You’ve probably even found a few applications you really love and work with often. But there’s a difference between using AI and being fluent with it.
In this video, we'll explore AI fluency - using AI effectively, efficiently, ethically and safely. We're talking about skills that go beyond any specific tool or clever prompt—skills that lead to genuine mastery that will serve you whether you're working with today's AI or whatever comes next.
We’ll walk through the “4D” framework — four competencies that we hope will transform how you work with AI. Whether you’re gathering information, collaborating on projects, or even setting up AI systems to work independently on our behalf, these skills will make you more effective.
This video provides just a high-level overview of the framework, and we encourage you to explore the richer insights and exercises for each competency available in our AI Fluency Framework & Foundations course, which is linked in this lesson page.
At it’s core, AI fluency is about being a responsible human in the loop. Which means making decisions and using AI responsibly. It’s about augmenting, or adding to, the great work you already do. This is in contrast to simple automation, where people ask AI to do work for them without thinking deeply about what they’re asking, or what the impact might be. This is especially important in learning, where we really don’t want AI to do work for us. Instead we want AI to help us do our work better.
The 4Ds are Delegation, Description, Discernment, and Diligence. Think of them as four interconnected competencies that, when combined, create AI fluency.
Let's begin with Delegation—basically figuring out what we are trying to do and who should do it. Delegation asks: What work should humans do, what should AI do, and what should we do together? Simple, right? But splitting up the work effectively is the foundation of thoughtful AI collaboration.
Effective delegation requires three types of awareness:
First, Problem Awareness. Before you even pull up an AI assistant, get clear on what you’re actually trying to do. Studying for a test? Sure, but what do you need to do? Review vocabulary? Prepare for case studies? What does success look like? The clearer you are about your goals at the outset, the easier it is to stay true to your original intention as you work with AI. Occasionally, you may revise your problem awareness during the course of AI collaboration, but it should exist as your north star as you work with AI. Your understanding of the problem is the foundation of fluent AI use.
Second, Platform Awareness. Not all AI is the same. Different AI systems have different capabilities and limitations. Some are great at complex reasoning, some are custom-built to aid student learning. If problem awareness tells us the job that needs doing, platform awareness helps us find the best tool or partner to get the job done. It’s like choosing how to get to class, you might walk, bike, bus, or drive, it all depends on your specific circumstances.
Finally, there’s Task Delegation. Task delegation is where you actually divide the work between yourself and AI to leverage the strengths of each. Us humans bring creativity, judgment, and real world context. AI offers speed, consistency, and the ability to process vast amounts of information. The best results happen when we play to both strengths
Next, let’s look at Description.
Description is how you actually talk to AI. But it’s more than just prompting, it recognizes that working with AI fluently is more like having a conversation with a collaborator, not memorizing perfect prompts or giving commands.
Consider these three dimensions of description:
Product Description is about what you want from the final result. The more detail the better. Don’t just say “I need to write an email” specify how long it should be, the key messages, who the email is going to, what style should the writing be in, and so on. the outputs, format, intended audience, and style of the final product itself.
Process Description is about how the AI should approach your request. Imagine you’re teaching another person how to do the task—whatever you’d say to them is what you might consider saying to the AI assistant. For example, you might ask the AI to "think step-by-step," "consider multiple perspectives," or "start with the most important points." This helps guide AI's thinking process for a final result that is more aligned to your vision.
Finally, Performance Description defines how you want AI to behave during your interaction. Need a critical editor who challenges your ideas? Say so. Want supportive brainstorming? Ask for it! You shape how your AI assistant responds.
While Description is about explaining what we want, Discernment is about our ability to recognize a good or bad result. It involves having good judgement about what AI produces and knowing how to adapt and adjust accordingly.
Good discernment protects against errors and might even allow you to explore new creative ways to accomplish your goals with AI’s help. Like Description, it works on three levels: product, process, and performance.
Product Discernment evaluates the quality of what the AI creates. Is the information accurate? Do the suggestions actually help? But also—did the AI show you something you hadn’t considered? This is both about checking for factual inaccuracies, as well as opening up your thinking to new perspectives, much like you would when working with a friend.
Process Discernment examines how the AI got there. Did it consider all relevant factors? Make reasonable assumptions? Follow logical steps? Understanding the AI's reasoning can help you trust good outputs and spot problems.
Performance Discernment is about how the AI behaved during your interaction. Was it helpful in the way you needed? Did it stay in the role you asked for? Push back when appropriate? This awareness helps you adjust future interactions.
Remember: Good discernment is not just hunting for errors. It’s also recognizing when the AI surprises you or genuinely helps you think better. Sometimes AI suggests approaches you hadn't considered, makes connections you missed, or frames ideas in illuminating ways.
As we mentioned before, Description and Discernment work together in a continuous feedback loop. You describe what you want, discern what you get, then adjust and refine your description. It's like any good conversation—you build understanding together. This iterative process is where real AI fluency develops.
Each round of conversation deepens the collaboration. What starts as “help me think through some ideas I have  for my essay” evolves into nuanced thinking about structure, arguments, and evidence. This loop transforms AI from a tool that follows instructions into a partner that helps you think and achieve your goals better.
Last but not least, let’s talk about Diligence. Diligence is about taking responsibility for how we use AI, and it is important at every stage of AI collaboration. Diligence ensures AI use remains responsible, transparent, and ethical. This isn't some boring compliance thing. It's about using AI in ways you can feel good about and stand behind.
First is Creation Diligence, which involves thoughtfully selecting which AI systems we use and how we interact with them. When picking an AI assistant, consider privacy, security, and appropriateness for your specific context. Using AI for personal brainstorming? Cool. Using it for complex analysis? Also great. But different situations call for different approaches.
Next is Transparency Diligence, which means  being honest about how you worked with AI. Your professors, teammates, and future employers deserve to know when AI helped you and how. Done right, you have nothing to hide— in fact you're showcasing your ability to collaborate with AI fluently which has become a critical professional skill.
Finally, there’s Deployment Diligence which means taking ownership of what we create with AI. We verify accuracy, ensure appropriateness, and take responsibility for what we put out into the world. AI might draft the email, but you send it. AI might suggest ideas, but you choose which to use. We're always responsible for the final result.
The 4Ds really come alive when you use them together — and like anything, they improve with practice. You may be watching this video as a part of an online course, in school, or for your own learning, but trying it out in practice is where you’ll likely really start understanding what we mean and how the 4Ds can change how you work with AI.
Each time you thoughtfully delegate work, carefully and clearly describe your needs, critically evaluate and discern outputs, and diligently take responsibility for the results, your fluency grows.
Our hope is that the 4Ds remain relevant even as AI technology evolves. New capabilities will come, but the need for strategic thinking, clear communication, critical evaluation, and ethical responsibility will endure.
Start practicing with your next AI interaction. Notice which D you're using. Try being more intentional about each one. You'll be surprised how quickly your AI collaborations improve.
That's the framework—now go make it yours!

#### Key takeaways

- The 4Ds work together to create genuine AI Fluency
- Augmentation (working with AI) is more valuable than automation in the learning context (AI doing work for you)
- Description and Discernment form a continuous improvement loop
- These competencies remain relevant regardless of how AI technology evolves

### Exercises

This foundational exercise helps you establish your learning context and goals, creating a reusable document for future AI collaborations. Always be careful when sharing information with an AI (or any computer system). Protect your privacy and the privacy of others.

#### Step 1: Self-reflection (5 minutes)

Before engaging with AI, clarify your own position as a learner. Consider your:

**Academic context:**

- What are you studying and at what level (major, year, specific courses)?
- What are your strongest and weakest subject areas?
- What types of assignments do you typically work on?
- What are your academic goals this term and beyond?

**Learning style and challenges:**

- How do you learn best (visual, verbal, hands-on, etc.)?
- What aspects of learning do you find most challenging?
- Where do you typically need the most help or support?
- What motivates you to learn and persist through difficulties?

**AI experience and goals:**

- What experience do you already have with AI tools?
- What concerns do you have about using AI in your studies?
- What do you hope AI can help you achieve academically?
- What boundaries do you want to set for AI use in your learning?

#### Step 2: Creating your learning context document with AI (15 minutes)

Start a conversation with Claude (or your preferred AI assistant):

**Opening the conversation:**

- Explain that you're a student building a learning context document
- Tell the AI this will help establish how you can work together effectively on academic tasks
- Make it clear that you want to use AI to enhance your learning, not replace it

**Key areas to explore with the AI:**

- Your current courses and learning challenges
- Your goals and what success looks like for you
- Your preferred study methods and what helps you understand concepts
- Situations where you want AI support versus where you want to work independently
- Your school's AI policies and how to work within them

**Building the document together:**

- Share the reflections from Step 1 with the AI
- Let the AI ask follow-up questions to understand your context better
- Be specific about examples of assignments or concepts you're working on
- Discuss what kind of AI support would actually help you learn versus just complete tasks

**Important boundaries to establish:**

- Make it clear you want to learn, not have work done for you
- Discuss how you'll maintain academic integrity
- Establish when you'll work with AI versus independently
- Set expectations for the type of help you want (guidance, practice, feedback, etc.)

#### Step 3: Finalizing Your Document (5 minutes)

**Creating your reference document:**

- Ask the AI to synthesize your discussion into a structured learning context document
- Review it together and make any necessary adjustments
- Include a section on "How I Want to Work with AI" based on your boundaries
- Save this document to share at the start of future AI learning sessions

**Reflection questions:**

- What surprised you about articulating your learning needs?
- How do you think having this context will improve your AI interactions?

### What's next

In the next lesson, we'll explore using AI as a genuine learning partner. You'll discover the crucial difference between having AI do work for you versus helping you learn, create an AI study buddy configured for your needs, and build a learning journal system that tracks your real growth over time.

---

## (AI Fluency Framework applications for students)AI as a learning partner

Estimated time: 55 minutes

### What you'll learn

By the end of this lesson you'll be able to:

- Distinguish between using AI to do work versus using AI to learn
- Apply the 4Ds specifically to learning contexts
- Create an AI learning partner that enhances rather than replaces learning
- Build a living learning journal that tracks your growth over time

### AI as a learning partner

This video explores the crucial difference between using AI to do work for you versus using AI to actually learn. It walks through each of the 4Ds in a learning context: Delegation means maintaining problem awareness about what you're trying to learn and choosing AI systems designed for education; Description involves steering AI to act as a tutor or coach rather than an answer-giver; Discernment requires honestly evaluating whether you're truly learning or just along for the ride; and Diligence means following academic policies while maintaining the ability to explain and stand behind all your work. The video emphasizes that genuine learning with AI takes more effort than shortcuts but builds real understanding and skills that will serve you in exams, interviews, and your career.

#### Video (AI as a Learning Partner)

Let's talk about something that's probably on your mind if you're a student right now: how do you use AI to actually learn things (and not just make homework go faster).
There's a fundamental difference between using AI to do work for us, and using AI to do our work better, and to actually learn. That’s what we’ll explore here.
When we regularly let AI think for us, we miss out on the opportunity to build the critical thinking muscles that allow us to thrive and solve problems in the real world.
The consequences here can be significant. Picture yourself in that high-stakes exam with no AI to bail you out, or sitting in a job interview where you need to actually explain your thinking, or giving a presentation trying to articulate your thoughts. Maybe you’re at work and AI gives you advice, but you haven’t developed the evaluation skills to tell if it’s genius or garbage, and to make things worse, you’re facing a real-world problem that you alone are responsible for solving—suddenly all that borrowed intelligence isn't so helpful.
The good news is, there are ways to use AI as a learning partner that can give you the support you need and make you more knowledgeable and more capable. It's not always the easiest path, but it's the one that actually sets you up for success. That’s what AI Fluency is about.
Let’s start with Delegation. Remember that Delegation means making thoughtful decisions about what you should do versus what AI should do.
First, you need Problem Awareness. Before you even call on an AI assistant, ask yourself: What am I trying to achieve? What am I meant to learn from this piece of work? What approach will help me get to my goals as a student?
Once you're clear on the learning goal, you can make smart decisions about delegation. If the goal is to improve your argumentative writing, you shouldn't ask AI to write your arguments for you. But you could ask AI to be your debate partner, throwing counterarguments at you while you develop your own position. This is task delegation with a learning twist—you stay in the driver's seat while using AI to challenge and strengthen your thinking.
Some AI systems are specially built for learning, while others just want to give you answers no matter what. Good Description, which we’ll cover next, will help you steer an AI’s behavior to serve you best, but good Platform awareness might also help you to pick an AI assistant that has been designed with learning in mind.
Description lets us talk to AI in ways that support learning.
As we mentioned earlier, not all AI systems will be structured for learning by default, but that doesn’t mean you don’t have the power to steer that. Some AI systems are great at following instructions, which allows you to adapt the AI assistant’s behavior and outputs to whatever helps you learn best.
Most AI systems are designed to be helpful, which usually means they want to give you direct answers off the bat. But when we’re trying to learn, that actually doesn’t help at all. This is where we need to get specific about what kind of help we want. We can tell the AI exactly what we want it to act as—for example, like a tutor or professor—or the way we want it to act, such as only asking us questions to help us strengthen our thinking. We can also tell the AI what sort of output is most helpful for our learning, such as a worksheet, bullet point list, or a table that continually updates across our conversation to help us visualize your thoughts.
Try starting conversations with descriptions like: "I'm a freshman in college working on understanding algae photosynthesis at the cellular level. Instead of explaining it, can you ask me questions that connect to last week’s learning to help me think through this?"
Or: "I'm struggling with this logarithm problem I pasted into the chat. Without solving it for me, can you point me in the right direction to get started, and maybe give me a few really simple practice problems we can work through together?” or “I just wrote my analysis of this poem. Can you ask me questions that help me dig deeper into my own interpretation?"
See the pattern? We’re asking AI to be a coach, not a substitute player.
Here are some other ways you can ask AI for outputs that help you hone your skills instead of just giving answers.  Pointers or clues when working through a tough topic Questions that test your comprehension or make you think about how to apply an idea in practice Critical feedback on your ideas from another perspective Re-explaining concepts learned using different examples, or Practice problems that build on the ones in your homework One of our favorites is to ask an AI to act as YOUR student. Teaching a concept to someone else is a great way to lock in your own learning.
Another important skill is Discernment. Not just checking the quality of what the AI is giving you, but checking whether or not the interaction is actually getting you closer to your goal. You need to be really honest with yourself: Are you actually learning, or are you just along for the ride?
Here’s a quick gut check: Can you explain what you learned to someone else? Could you solve a similar problem without AI? Do you understand why something works, not just that it works? If you’re using AI as a learning assistant — asking questions, receiving guidance, working through problems together – the answers to these questions are more likely to be yes.
And remember what we said at the start - this isn’t the easy road. That frustrated feeling when you're stuck? That's literally your brain building new connections. AI can help you figure out how to unravel those knots in a way that helps you learn.
Trust yourself here—you know when something feels like genuine understanding versus just following along.
But Discernment is even trickier if you’re learning. Without a solid foundation, it can be hard to  know if AI is giving you accurate information. We’re ultimately the ones responsible for what we do with the information AI gives us, including what we learn from it. Just like how we should verify everything we see on the Internet, we owe it to ourselves to verify important knowledge that comes from AI, by using other non-AI sources.
Finally, let's talk about Diligence—working with AI responsibly and with academic integrity.
This shows up in three main ways:
First is Creation diligence: Use the AI systems your school actually allows and follow your school’s policies. Chances are, this guidance is developed with learning in mind. And if you’re curious about why certain policies exist, try using AI to explore the reasoning—ask it about the learning science behind different approaches, or how various AI uses might impact skill development. Understanding the 'why' helps you make smarter choices even in situations where the rules aren't spelled out.
Second is transparency diligence. We encourage you to be upfront about how you engage with AI. If you’ve committed to disclosure requirements, of course, follow them. But even when it's not required, documenting  how you interact with AI is a skill in itself that we build through practice. Transparency helps us communicate both our AI and non-AI skills, knowledge, and activities to teachers, employers, teammates and clients. This is becoming critical in both education and employment contexts.
ALT: But even when it’s not required, tracking how AI helped you can be an act of reflection, enabling you to  better understand your learning process and recognize well-deserved progress.
Finally, deployment diligence. This is the ultimate test: If you turn in work, you should be able to explain every part of it, stand by it, and apply the concepts to new situations. If someone asks "why did you approach it this way?" and you can't answer because AI made that choice, you haven't really learned—and that's going to catch up with you when you need those skills for real.
We get it. Using AI to actually learn instead of just complete assignments takes more effort. It's tempting to take shortcuts.
But knowing how to use AI to genuinely enhance your learning will set you apart as both a student and in your career. It won’t just make your homework easier. Students who get this right will walk away with real understanding, stronger problem-solving skills, and the confidence to handle whatever curveballs come next. You’ll understand the unique role that human intelligence, creativity and judgement play in AI-assisted work. You’ll feel confident in interviews. You’ll be able to spot when AI gives good or bad advice. You’ll become the colleague everyone wants on their team.
This approach is an investment in your future. You're not just getting through school. You're becoming someone who can think, learn, and adapt. In a world where everyone has access to AI, that's your actual superpower. The choices you make today shape the thinker you become tomorrow. Happy learning!

#### Key takeaways

- We should seek to use AI in ways that strengthen our knowledge and critical thinking skills, not weaken them.
- Effective learning with AI means staying in the driver's seat while AI challenges and supports you
- AI should act as a coach or tutor, not a substitute player
- You must be able to explain and apply everything you submit, even if AI helped
- The harder path of genuine learning with AI leads to real capability and confidence

### Exercises

This exercise helps you create two powerful learning tools: an AI study buddy configured for your needs, and a living learning journal that tracks your growth.

#### Part 1: Configuring your AI learning partner (15-30 minutes)

Start a new conversation with Claude (or your preferred AI assistant), or continue from Lesson 1:

**Setting up your learning partner:**

- If starting fresh, share your learning context document from Lesson 1
- Share the video transcripts from lesson 1 and lesson 2 to help the AI understand AI Fluency and the approach you are taking
- Explain that you want to configure the AI as a study buddy for ongoing use
- Specify that you want help learning, not completing assignments

**Establishing the learning partner's role: Work with the AI to define how it should help you learn:**

- Ask it to always start by understanding what you're trying to learn before helping
- Request that it asks you questions rather than giving direct answers
- Have it check your understanding before moving to new concepts
- Ask it to provide practice problems that build on what you're studying
- Request that it points out connections to things you've learned before

**Creating your study protocols: Develop specific approaches for different learning needs, for example:**

- **For problem-solving**: "Guide me with hints and questions, don't solve it for me"
- **For concept review**: "Test my understanding with progressively harder questions"
- **For exam prep**: "Quiz me and explain why wrong answers are wrong (and why correct answers are correct)"
- **For writing**: "Help me develop my own arguments through questioning"
- **For reading comprehension**: "Ask me to explain key concepts in my own words"
- **For general planning**: "Gather information from me about my various commitments so I can effectively plan out coursework and other activities I need to complete/attend"
- **For specific assignment planning**: "Help me test my understanding of this assignment brief so I am sure I understand what is expected of me"

**Testing your learning partner:**

- Try a real example from your current coursework
- See if the AI maintains its tutoring role or slips into just giving answers
- Adjust the instructions if needed
- Save the configuration instructions as a conversation guide for future use

#### Part 2: Creating your living learning journal (15-30 minutes)

Start a fresh conversation to set up a learning journal system, as you will want to come back to it regularly. Start by sharing your learning context document from Lesson 1, and the video transcripts from lesson 1 and lesson 2. Explain that you want to create an ongoing conversation to act as a living learning journal.

**Designing your journal structure: Work with the AI to create a template for regular learning reflections:**

- What concepts did I work on this week?
- What clicked for me and what's still fuzzy?
- How did I use AI to help me learn (not just complete tasks)?
- What study strategies worked well?
- What do I need to review or practice more?
- One specific skill or understanding I developed

**Setting up your tracking system:**

- Decide on frequency (weekly is recommended)
- Create a format that's easy to maintain
- Include space for noting when AI helped versus independent work
- Add a section for "aha moments" and breakthroughs
- Plan for monthly synthesis entries that identify patterns

**Creating your first entry:**

- Reflect on your learning from the past week
- Document one specific example of using AI as a learning partner
- Note what you learned versus what you just completed
- Identify areas where you need more practice
- Set a learning goal for next week

**Building accountability:**

- Ask the AI to help you create reflection prompts
- Set reminders to update your journal
- Plan to review entries before exams to see your progress
- Consider sharing insights with study groups or advisors

**Lesson reflection:**
After setting up both tools, ask yourself:

  - How were these exercises different from other AI interactions you have had in the past?

### What's next

Now that you have your AI learning partner and journal set up, the next lesson will show you how to apply these same principles to career development. You'll learn to use AI strategically for job searching, interview prep, and professional growth while maintaining your authentic voice.

---

## (AI Fluency Framework applications for students)AI in career planning

Estimated time: 55 minutes

### What you'll learn

By the end of this lesson you'll be able to:

- Use AI thoughtfully for career exploration, skill building, job searching and job application support
- Create authentic application materials with AI support while maintaining your unique voice
- Practice interview skills with AI as your coach
- Build a strategic approach to career development that leverages AI appropriately

### AI as a career planning

This video explores how to use AI as a thinking partner for career planning rather than a machine that makes decisions or creates generic content for you. It covers three main areas: career mapping (where AI provides information while you provide self-knowledge and values), skill building (where AI acts as a coach for developing specific capabilities), and job searching (where AI helps with research and practice while you maintain authenticity). The video emphasizes that employers can immediately recognize generic AI-generated application materials, and that AI Fluency itself is becoming a valuable career skill worth highlighting. Throughout, the focus is on using AI to enhance your career planning while ensuring all representations of yourself remain authentic.

#### Video (AI in Career Planning)

Career planning – figuring out what you want to do, the skills you need to do it, and how to land that dream role is overwhelming for just about everybody.
In this video, we’ll talk about how AI can support you in each of these tasks—but not in the way you might think.
Instead of just cranking out resumes or cover letters that recruiters can immediately tell is generic AI content, we're going to walk through using AI to help you identify roles that suit you, the skills you need to get them, and strategies to land opportunities in a way that feels authentic to you.
You’ve probably seen advice about using AI to optimize resumes or write cover letters.
Unfortunately, these tips are often applied without fluency, and the end results are generic, forced, and don’t impress employers.
When you use AI thoughtfully in your career building process, it can support both your immediate job search and your long-term career success. The key is to engage with AI as a thinking partner that helps you develop your own career strategy, not as a service that makes decisions (or content) for you.
Instead of looking at the 4Ds individually, let’s walk through the actual process of career planning with AI, from mapping your career goals and building skills, to landing your dream role.
So you’ve likely been asked something along the lines of ”what do you want to do with your life?” No pressure, right? This is exactly the kind of question we don’t want to hand over to AI completely. But that doesn’t mean you can’t lean on AI to help you think this through. AI Fluency means knowing that AI can help you with things like brainstorming potential career paths you hadn't considered or connecting dots between your background and your dream role that you might miss on your own. But it also means recognizing there are many times when you shouldn't engage with AI at all—times when you need to trust your own expertise instead.
Career exploration has two important parts: gathering information about the workforce, and a lot of personal reflection. 
AI is fantastic at the information part—it can tell you what's out there, what skills companies are actually looking for, how entire industries are shifting. It can also conduct broad research that to save you a lot of time. But of course, only you know what energizes you, what tradeoffs you’ll accept, what aligns with your values, and what kind of life you want to build.
The most effective approach pairs  your own self-knowledge and gut instincts with AI to find, understand, and analyze a ton of information, together.
Here are some ways you might put AI to work in your career exploration:
Industry research and trend analysis - for example, you can ask AI to conduct research that answers the question, “What are the emerging roles in sustainable tech that combine environmental science with data analysis?”
Skill gap identification for target roles - for example, “I want to be a UX designer. What specific skills do employers actually look for vs what bootcamps teach?”
Salary and job market insights, especially with AI systems that can search and synthesize from across the web. For example, “What's the real salary progression for entry-level consultants in different cities?”
Typical trajectories and timelines for career growth or pivots, such as “Show me different ways people have transitioned from teaching to corporate training roles”, and Brainstorming roles that help you get where you want to go - for example, "What careers use similar skills to journalism but have better job stability?"
Finally get AI to ask you questions to draw out your own career goals and values - often we haven’t made these explicit, even to ourselves.
After all this exploration, let’s say you find that there is actually a gap between where you are and where you want to end up. How can AI help then?
That's where skill development with AI comes in. Using AI for skill development is, in many ways, similar to using it as a learning partner.  The trick is being specific about what you're trying to learn and getting AI to actually coach you through the process, not just dump information on you.
Smart skill development with AI starts with being honest about where you're at right now and exactly what you need to accomplish. Be specific about your learning needs—instead of "help me learn data analysis," try "I'm a marketing manager who needs to get better at analyzing customer survey data for campaign decisions. I think I should start with the basics of Excel pivot tables, but I’m not sure. Please help me figure out a plan, including opportunities to practice. And then let’s actually do it!". Collaborate with AI as a coach.
You can try:
Getting it to create practice scenarios from your target industry
Ask for feedback on your work samples
Have it roleplay situations you'll face, such as pretending to be an interviewer from a specific team and challenge you with practice questions and feedback
Check in with yourself regularly: Are you actually learning or just going through the motions? If you don’t think you’re growing and improving, try working with AI differently.
Once you've got your skills moving in the right direction, it's time for the big challenge: actually landing the job.
Job searching involves many tasks: researching companies and roles, crafting application materials that authentically represent your experience, and preparing compelling stories that will make interviewers remember you. The 4D framework can help guide each task to ensure you’re showing up as your best self.
Here’s a good rule of thumb: AI can handle the brainstorming and coaching, helping you practice and giving general feedback. It can even write drafts that you take bits and pieces from to form your final set of application materials, but ultimately, you’re responsible for presenting … you.
For example:
Let AI help you identify your transferable skills
Engage with AI to practice answering tough interview questions
Have it help you find unique angles for cover letters
Remember though that your professional expertise and career goals should drive your AI collaboration process—AI doesn't know what fulfills you or what trade-offs you're willing to make.
As you work with AI, evaluate suggestions against your authentic professional identity. Whether it’s a job application, resume, cover letter, or even a social media post, you ultimately take responsibility for how you represent yourself professionally. AI may be able to help you tell your story better, but it starts and ends with your expertise.
One last thing, Fluent AI use includes keeping track of your AI interactions and being upfront about AI assistance when it makes sense to mention it.
Don’t shy away from that — AI fluency itself is becoming a valuable career skill! Employers want people who can work with AI effectively, which is exactly what you’re learning and practicing here.
By taking this course and working to build your AI fluency, you're going beyond just a job search to developing skills that’ll matter across your future career.
Add that to your resume!

#### Key takeaways

- Career planning combines AI's information gathering with your self-knowledge and values
- Generic AI-generated resumes and cover letters are easily spotted and ineffective
- AI excels at research, brainstorming, and practice but you must drive the strategy
- Skill building with AI requires specific goals and active practice, not passive consumption
- AI Fluency is itself a valuable career skill to develop and showcase

### Exercises

This comprehensive exercise takes you through a complete career development process using AI strategically at each stage. The timing is just a guideline - don't feel like you need to rush anything!

#### Part 1: Career exploration & self-discovery (15 minutes)

Start a conversation with Claude (or an AI of your choice) about career exploration:

**Setting up the conversation:**

- Share your academic background (or reuse your document from lesson 1) and any work experience
- Explain you're exploring career options and want AI to help you research and reflect
- Emphasize you want to discover what's right for you, not have AI decide

**Information gathering with AI:**

**Ask the AI to help you research:**

- What careers use skills similar to your major but in different ways
- Emerging roles in your field of interest over the next 5-10 years
- Real salary progressions and job market demand in your target locations
- Day-to-day realities of roles you're considering
- Multiple paths people have taken to reach positions you find interesting

**Self-reflection with AI guidance:**

**Have the AI ask you questions to explore:**

- What energizes you versus drains you in your current activities
- What trade-offs you're willing to make (salary vs. flexibility, stability vs. growth)
- Your values and how different careers might align with them
- Your definition of success beyond just job titles
- What skills you genuinely enjoy using versus just happen to have

**Creating your career map:**

- Ask the AI to summarize potential paths based on your discussion
- Identify 2-3 roles that genuinely interest you
- Note skill gaps between where you are and where you want to be
- Save this exploration for reference

#### Part 2: CV/resume improvement workflow (15 minutes)

Now practice this systematic CV/resume improvement workflow:

**Step 1: Initial CV/resume Critique (5 minutes) In a new conversation (or clearly separated section):**

- Share your current CV/resume/resume
- Provide a specific job spec (either an opportunity you are currently targeting or one representative of your general target)
- Ask the AI to
  - Analyze the job spec: What skills, experiences, etc are they looking for? Given the general role, are there other criteria that are not mentioned but are relevant.
  - Analyze your CV/resume in the context of this particular job spec
  - Provide a specific to-do list of improvements for you to consider. Get the AI to focus on what's missing, what's unclear, and what doesn't align with the role.
- Discuss these analyses and to-do list to make sure you understand them all - YOU are applying for this job, not the AI

**Step 2: Information Gathering (5 minutes)**

- Ask the AI to gather information from you - whatever it needs to know to help you address each point on the to-do list. Get the AI to help you remember and unpack relevant experiences and achievements.
- Answer the AI's questions honestly and with specific examples and details
- Work with the AI to articulate your experiences more effectively

**Step 3: CV/resume Revision (5 minutes)**

- Now, based on the information gathered, work with the AI to address specific to-do items and revise specific sections of your CV/resume
- Focus on incorporating your actual experiences in stronger language
- Ensure every point can be backed up with real examples
- Remember: this is YOUR experience, just better articulated
- Create a final version of the CV/Resume that feels authentic to you

#### Part 3: Interview Preparation (15 minutes)

**Mock interview setup:**

- Start a fresh conversation for interview practice:
- Share your revised CV/resume and the job description
- Ask the AI to analyze the role and think about 5 common and realistic interview questions.
- Then get the AI to ask you these questions, referencing details from your CV/resume when appropriate.
- Important: Specify you want the AI to:
  - ask only one question at a time, and to wait for an answer
  - ask at most one follow up question if needed and wait for an answer
  - Then to move on to the next question
- Answer each question as if in a real interview
  - Try to include specific examples from your experience
  - Bonus: practice explaining any AI-assisted projects honestly - flex your AI Fluency
  - Focus on demonstrating understanding, not just reciting prepared answers
- At the end, ask the AI to critique each of your answers in terms of content, clarity, style and relevance

***Shake it up:** You can easily adapt this workflow to prepare cover letters and other communications (not just your CV/resume)

**Key things to keep in mind:**

- The AI is helping you practice and prepare, but in the actual interview, you need to be genuinely present and authentic.
- Don't try to memorize scripts. Try to understand your experiences well enough to discuss them naturally and flexibly no matter what the question is about.
- Employers want to hire YOU, not an AI's version (or anyone else's version) of you

### What's next

In our final lesson, we'll explore what it means to be "the human in the loop." You'll create a personal AI collaboration policy that reflects your values, develop guidelines for responsible AI use, and build a framework for continued growth in AI fluency that will serve you throughout your academic and professional journey.

---

## (Conclusion & certificate)Being the human in the loop

Estimated time: 40 minutes

### What you'll learn

By the end of this lesson you'll be able to:

- Understand what it means to be "the human in the loop" in AI interactions
- Create a personal AI collaboration policy that reflects your values
- Develop guidelines for responsible AI use in your academic and professional life
- Build a framework for continued growth in AI Fluency

### Being the human in the loop & developing a personal commitment

This video explores what it means to be "the human in the loop"—the decision-maker who steers AI interactions with judgment, creativity, and ethics. It emphasizes that being human in the loop means you decide what to ask, evaluate whether AI outputs make sense, and bring your values to every interaction. The video encourages creating a personal AI collaboration policy that includes when you'll engage with AI (and when you won't), how you'll use it for learning, transparency commitments, and strategies for keeping skills sharp. It stresses that continuous reflection on AI practice is crucial, asking questions like: Is this helping me grow? Am I developing needed skills? Am I being honest about AI's role? The video concludes by highlighting that your humanity—your specific talents, experiences, and perspectives—remains uniquely valuable and irreplaceable.

#### Video (Being the human in the loop & developing a personal commitment)

AI fluency enables you to collaborate with AI safely, efficiently, effectively and responsibly, whether you’re using it for learning, career planning, or any other number of applications.
At its core, it’s about becoming someone who can thrive in a world where AI is everywhere, someone who approaches these systems with confidence, control, and clear values. In tech speak, it's about being really good at being 'the human in the loop’.
The term “human in the loop” has been popularized in the AI world and it can sound a bit vague, but it basically refers to the idea that in every AI interaction, the human is the one making the decisions and steering the ship.
It means you decide what to ask. You evaluate whether what the AI gives you actually makes sense. You decide if it's good enough to use. You're not just passively accepting whatever pops up—you're bringing your judgment, your creativity, and your sense of right and wrong to every interaction.
This matters because AI is becoming part of almost every aspect of our lives—from how we learn and work to how we communicate and analyze problems. The leaders of tomorrow are those who know how to partner with these systems thoughtfully.
Here’s something we encourage you to try: write down your own AI collaboration guidelines, including a personal commitment to engage with AI responsibly. This is a chance to think deeply about your values and how you want to engage with AI technology. Your commitment can be as long or as short as you’d like, and might include things like:
What kind of human in the loop you want to be (meaning when you’ll engage with AI, and when you won’t)
How you want to use AI in learning
When and how you’ll disclose your AI assistance, and
How you'll keep your skills sharp even with AI available
You may even think about how you would want or not want others around you to engage with AI as a way to inform your own perspective.
We suggest you keep it real. This isn’t about writing what sounds good. This commitment should be your north star for AI engagement. It'll help you notice when you're leaning on AI in ways that feel true to you and your values, and when something feels off.
The best AI users do something most people skip: they continuously reflect on their practice. They ask hard questions: Is how I'm engaging with AI helping me grow? Am I developing the skills I need for my future or just completing tasks? Am I being honest about AI’s role in my work? And ultimately, am I using AI in ways that align with my values?
This kind of reflection keeps you growing. We encourage you to step back every now and then and reflect on your own personal journey with AI Fluency.
As you continue through school and into your career, you're going to run into AI applications that don't even exist yet. New systems will pop up seemingly overnight. AI will get better at things we didn't think it could do. New ethical questions will surface.
But if you've built strong AI fluency—if you can delegate thoughtfully, describe what you need clearly, think critically about what you get back, and follow through with care—you'll be ready for whatever comes next.
Even better, you'll become someone who actually influences how AI gets used in your field, your community, and the wider world. Instead of just going along with whatever changes happen, you'll be helping steer those changes in positive directions.
Remember that your humanity is uniquely valuable. Your specific talents, life experiences, knowledge, the way you see things, your relationships with people—all of this shapes how you understand and respond to the world in ways that are completely your own.
AI can help you be aware of and express these qualities more effectively. It can help you learn faster, communicate more clearly, and solve problems more creatively.
But it can't replace the human insight, judgment, and care that you bring to everything you do.
So what's next? Start by writing that personal commitment. Reflect on what responsible AI use means to you. Share it with friends or mentors if you're comfortable—having others know your standards helps you live up to them.
Then, put it into practice. Try out the 4D framework in your everyday life—delegating thoughtfully, describing clearly, discerning critically, and following through with diligence. Pay attention to when you're nailing it and when you're not. Celebrate the wins and learn from the moments when things don't go as planned.
Most importantly, remember that AI fluency is a journey, not a destination. Stay curious, stay ethical, and don’t lose sight of what makes you human. The future needs people like you—people who can work with AI responsibly and help others do the same.
Thank you for joining us on this journey toward AI fluency. Now go out there and be the human in the loop that our world needs.

#### Key takeaways

- Being the "human in the loop" means maintaining decision-making control in all AI interactions
- A personal commitment to responsible AI use helps navigate ethical complexities
- Regular reflection on AI practice ensures continued growth and alignment with values
- Your human insight, judgment, and care remain irreplaceable
- AI Fluency is a journey of continuous learning and ethical development

### Exercises

This comprehensive exercise helps you develop a thoughtful, practical policy for your AI use that you'll actually follow.

#### Part 1: Foundation Building (10 minutes)

Go offline to consider everything you’ve learned in this course and jot down your initial thoughts.

**Exploring your values and boundaries:**

Think through:

- Your core values around learning, integrity, and achievement
- Situations where you absolutely will not use AI (your "red lines")
- Areas where AI support feels appropriate and beneficial
- How you want others to perceive your AI use
- What kind of professional you want to become

In addition, consider the perspectives of others:

- How would you want your classmates to use AI?
- What would you think if your professor used AI in different ways?
- How would you want employees to use AI if you were an employer?
- What uses of AI would make you uncomfortable if others did them?

#### Part 2: Drafting Your Policy (20 minutes)

Share this context with AI and discuss different sections of your policy (sample topics below - make them your own!):

**Section 1: When I Will and Won't Use AI Define clear boundaries:**

- Learning situations where AI is appropriate (practice, exploration, building understanding, applying knowledge)
- Situations where I'll work independently (exams, demonstrating mastery, original thinking)
- Professional contexts where AI adds value
- Times when human-only work is essential
  
**Section 2: How I'll Use AI for Learning Specify your approach:**

- AI as tutor/coach, not homework completer
- Maintaining ability to explain everything I submit
- Using AI to enhance understanding, not bypass it
- Specific strategies that have worked for me

**Section 3: Transparency Commitments Define your disclosure standards:**

- When I'll proactively disclose AI assistance
- How I'll document AI contributions
- What level of detail I'll provide
- How I'll handle ambiguous situations

**Section 4: Skill Maintenance Protect your capabilities:**

- Core skills I'll practice without AI
- Regular "AI-free" work to maintain abilities
- How I'll verify I'm still learning
- Signs that I'm over-relying on AI (and signs that I may be under-utilizing AI!)

**Section 5: Ethical Guidelines Your personal ethics:**

- Accuracy and fact-checking responsibilities
- Respect for others' work and ideas
- Privacy and data considerations
- Other impacts of AI and computer use 

**Section 6: Continued Growth Planning for the future:**

- How I'll stay updated on AI capabilities
- Regular reflection intervals
- Adjusting policies as I learn
- Sharing knowledge with others

#### Part 3: Making It Real (5 minutes)

Review your draft policy with the AI:

- Is this realistic given your context and constraints?
- How will you maintain accountability?
- Practice applying the policy to a few real scenarios (a course revision, an assignment, a job application, even just a little personal project)
- Ask the AI to help format this as a clear, professional document
  - Keep it concise enough to actually reference
  - Include date created and plan for updates
  - Save in multiple places for easy access
- Use it and maybe share it and discuss it with a friend

### What's next

Congratulations on completing AI Fluency for Students! You now have:

- A framework (4Ds) for thoughtful AI interactions that are effective, efficient, ethical and safe
- An approach to AI augmented learning that enhances rather than replaces your own talent, effort and education
- An approach to AI augmented career thinking and job seeking that maintains authenticity while helping you to communicate your unique experiences more effectively
- A personal AI policy that reflects your individual values and sets you up not just as a responsible AI user but as an AI leader.

Take the final quiz in the next lesson to receive your certificate of completion of this course material.

---

## (Conclusion & certificate)Certificate of completion

Estimated time: 5 minutes

- Question 1: According to the AI Fluency Framework, what does AI Fluency mean? (a)
  a. The ability to work with AI effectively, efficiently, ethically, and safely
  b. Becoming a technical expert in AI development
  c. Memorizing the best prompts for different AI tools
  d. Using AI to automate all possible tasks

- Question 2: Which of the following is NOT one of the 4Ds in the AI Fluency Framework? (a)
  a. Documentation
  b. Delegation
  c. Discernment
  d. Description

- Question 3: Which approach best demonstrates using AI as a learning partner rather than a substitute? (a)
  a. Requesting AI act as a debate partner to challenge your arguments
  b. Using AI to quickly finish assignments so you have more free time
  c. Asking AI to write your essay completely
  d. Having AI explain the answer to every homework problem

- Question 4: What's an effective way to verify you're actually learning when using AI? (b)
  a. Count how many AI conversations you've had
  b. See if you can explain the concept being learned to someone else
  c. Compare AI's answer to the textbook
  d. Check if AI gave you the correct answer

- Question 5: What is this course's recommended approach for using AI in job application materials? (c)
  a. Never use AI for any professional documents
  b. Let AI write everything to ensure perfect grammar
  c. AI can brainstorm and draft, but you must authentically represent yourself
  d. Only use AI for cover letters, never resumes

- Question 6: Why should you track and sometimes disclose your AI interactions in career contexts? (a)
  a. Transparency is an important part of AI Fluency which is itself becoming a valuable career skill
  b. Employers can always detect AI use anyway
  c. It's legally required for all job applications
  d. It guarantees you'll get the job

- Question 7: What does being "the human in the loop" mean? (d)
  a. You should avoid using AI for important tasks
  b. You must manually review every AI output
  c. You need to understand AI's technical programming
  d. You make decisions, steer the ship, and take responsibility in AI interactions

- Question 8: According to the lesson, what makes human contribution uniquely valuable when working with AI? (c)
  a. Humans work faster than AI systems
  b. Humans don't need any training or practice
  c. Your specific insight, judgment, and care
  d. Humans are always more accurate than AI

---

<notes>
<critical>
Below are notes from a video course about working with the Claude language model.
Use these notes as a resource to answer the user's question.
Write your answer as a standalone response - do not refer directly to these notes unless specifically requested by the user.
</critical>
<note title="Lesson 1: Introduction to AI Fluency & The 4D Framework">
AI Fluency = using AI effectively, efficiently, ethically, safely through enduring principles rather than temporary tips/tools

4D Framework = four interconnected competencies (Delegation, Description, Discernment, Diligence) that create AI fluency

Augmentation vs Automation:
- Augmentation = AI helps you do your work better (preferred for learning)
- Automation = AI does work for you without deep thought (problematic for learning)

Human in the Loop = making responsible decisions and using AI thoughtfully while maintaining ownership

DELEGATION = determining what work should be done by humans, AI, or together

Three types of delegation awareness:
- Problem Awareness = clarifying actual goals/objectives before using AI
- Platform Awareness = understanding different AI capabilities/limitations to choose right tool
- Task Delegation = dividing work to leverage human strengths (creativity, judgment, context) and AI strengths (speed, consistency, information processing)

DESCRIPTION = how you communicate with AI as collaborative conversation, not just prompting

Three dimensions of description:
- Product Description = specifying final result details (length, key messages, audience, style, format)
- Process Description = guiding AI's approach ("think step-by-step," "consider multiple perspectives")
- Performance Description = defining AI's behavior during interaction (critical editor, supportive brainstormer)

DISCERNMENT = recognizing good/bad results and adapting accordingly through critical evaluation

Three levels of discernment:
- Product Discernment = evaluating accuracy, helpfulness, new perspectives in AI outputs
- Process Discernment = examining AI's reasoning, assumptions, logical steps
- Performance Discernment = assessing whether AI behaved helpfully in requested role

Description-Discernment Loop = continuous feedback cycle where you describe needs, evaluate results, then refine descriptions iteratively

DILIGENCE = taking responsibility for AI use through ethical, transparent, accountable practices

Three types of diligence:
- Creation Diligence = thoughtfully selecting AI systems considering privacy, security, appropriateness
- Transparency Diligence = honestly reporting AI collaboration to professors, teammates, employers
- Deployment Diligence = taking ownership of AI-assisted outputs, verifying accuracy, ensuring appropriateness

Learning Context Document = personalized reference document establishing academic context, learning goals, AI boundaries, and collaboration preferences for future AI sessions

Key Elements for Learning Context:
- Academic context (major, courses, strengths/weaknesses, goals)
- Learning style and challenges
- AI experience and boundaries
- Preferred support types (guidance vs task completion)
- Academic integrity considerations

Essential Principle = AI fluency skills remain relevant regardless of technological evolution because they focus on strategic thinking, communication, evaluation, and ethical responsibility rather than specific tools
</note>

<note title="Lesson 2: AI as a Learning Partner">
**AI Learning Partner Framework**

Core Distinction = Using AI to do work vs using AI to learn
- AI doing work = borrowed intelligence, weakens critical thinking
- AI as learning partner = builds knowledge, enhances capability

**Consequences of AI Dependency**
- Exam failure without AI support
- Job interview difficulties explaining thinking
- Inability to evaluate AI advice quality
- Real-world problem solving deficits

**4Ds for Learning Context**

**Delegation (Learning Focus)**
Problem Awareness = Ask before using AI: What am I trying to learn? What's my learning goal?
Task Allocation = Keep learning-critical tasks (writing arguments), delegate support tasks (debate partner role)
Platform Selection = Choose AI systems designed for learning vs quick answers

**Description (Learning Configuration)**
Default AI Behavior = Designed to give direct answers (unhelpful for learning)
Learning Prompts = Configure AI as tutor/coach, not answer-giver
Effective Descriptions:
- "Ask me questions instead of explaining"
- "Point me toward solution without solving"
- "Help me dig deeper into my interpretation"

**Useful AI Learning Outputs:**
- Pointers/clues for difficult topics
- Comprehension testing questions
- Critical feedback from different perspectives
- Concept re-explanation with new examples
- Progressive practice problems
- Act as student for you to teach

**Discernment (Learning Evaluation)**
Learning Check Questions:
- Can I explain this to someone else?
- Can I solve similar problems without AI?
- Do I understand why, not just that it works?

Genuine Understanding vs Following Along = Trust internal sense of comprehension
Information Verification = Cross-check AI learning content with non-AI sources

**Diligence (Academic Integrity)**
Creation Diligence = Follow school AI policies, use approved systems
Transparency Diligence = Document AI interactions, develop disclosure skills
Deployment Diligence = Must explain every part of submitted work, apply concepts to new situations

**Exercise Structure**

**Part 1: AI Learning Partner Setup (15-30 min)**
Configuration Steps:
- Share learning context from Lesson 1
- Share video transcripts for AI understanding
- Specify learning vs assignment completion goals
- Define questioning vs direct answer approach

Study Protocols by Need:
- Problem-solving = hints/questions only
- Concept review = progressive difficulty testing
- Exam prep = quiz with explanation of wrong answers
- Writing = argument development through questioning
- Reading = explain concepts in own words
- Assignment planning = test understanding of requirements

**Part 2: Living Learning Journal (15-30 min)**
Journal Structure:
- Weekly concept work summary
- Understanding clarity assessment
- AI learning usage documentation
- Effective study strategy identification
- Practice needs identification
- Specific skill development notes

Tracking System:
- Weekly frequency recommended
- Monthly synthesis entries for patterns
- AI vs independent work notation
- "Aha moment" documentation
- Accountability through reflection prompts

**Key Outcomes**
Long-term Benefits = Real understanding, problem-solving skills, interview confidence, AI advice evaluation ability, workplace value
Investment Mindset = Building thinking/learning/adaptation capabilities beyond school completion
Competitive Advantage = Human intelligence/creativity/judgment skills in AI-accessible world
</note>

<note title="Lesson 3: AI in Career Planning">
AI in Career Planning = using AI as thinking partner for career exploration, skill building, job searching while maintaining authenticity

Core Principle = AI handles information gathering/coaching, human drives strategy/decisions/values

Career Exploration Process:
- AI strengths = industry research, trend analysis, skill gap identification, salary insights, trajectory mapping, brainstorming roles
- Human responsibility = self-knowledge, values, trade-offs, life goals, gut instincts
- Two-part process = information gathering (AI) + personal reflection (human)

AI Career Exploration Tasks:
- Industry research = "What are emerging roles in sustainable tech combining environmental science with data analysis?"
- Skill gap analysis = "UX designer skills employers want vs bootcamp teaching"
- Market insights = "Real salary progression for entry-level consultants by city"
- Career trajectories = "Transition paths from teaching to corporate training"
- Role brainstorming = "Careers using journalism skills with better stability"
- Values clarification = AI asks questions to surface career goals/values

Skill Development with AI:
- Specific learning needs = replace "help me learn data analysis" with "marketing manager needing customer survey analysis skills starting with Excel pivot tables"
- AI as coach = create practice scenarios, provide feedback on samples, roleplay situations
- Active learning check = regularly assess if actually improving or just going through motions

Job Search Applications:
- Rule of thumb = AI handles brainstorming/coaching/drafts, human presents authentic self
- AI tasks = identify transferable skills, practice interview questions, find unique cover letter angles
- Human responsibility = professional expertise, career goals, authentic identity, final materials

Generic AI Content Problem = recruiters immediately recognize AI-generated resumes/cover letters as ineffective

Career Development Workflow:
Part 1 - Career Exploration (15 min):
- Share background with AI
- Research careers using similar skills, emerging roles, salary progressions, day-to-day realities
- AI-guided self-reflection on energy sources, trade-offs, values, success definition
- Create career map with 2-3 target roles and skill gaps

Part 2 - CV/Resume Improvement (15 min):
- Step 1: AI critiques current CV against specific job spec
- Step 2: AI gathers information to address improvement areas
- Step 3: Revise CV incorporating actual experiences with stronger language

Part 3 - Interview Preparation (15 min):
- AI analyzes role for 5 realistic questions
- One question at time with follow-ups
- Practice with specific examples
- AI provides feedback on content/clarity/relevance

Key Guidelines:
- AI helps practice/prepare, human must be authentic in actual situations
- Don't memorize scripts, understand experiences for flexible discussion
- Employers want to hire you, not AI version of you
- AI fluency itself = valuable career skill to highlight
- Track AI interactions, be transparent about AI assistance when appropriate

Authentication Principle = AI can help tell your story better but story starts and ends with your expertise
</note>

<note title="Lesson 4: Being the Human in the Loop">
**LESSON 4: BEING THE HUMAN IN THE LOOP**

**Core Concept**
Human in the Loop = Human maintains decision-making control in all AI interactions. You decide what to ask, evaluate AI outputs for accuracy/sense, determine if output is usable. Bring judgment, creativity, ethics to every interaction.

**Key Principles**
- AI fluency = collaborating with AI safely, efficiently, effectively, responsibly
- Leaders of tomorrow = those who partner with AI systems thoughtfully
- Your humanity = uniquely valuable (talents, experiences, knowledge, perspectives)
- AI enhances human capabilities, cannot replace human insight/judgment/care

**Essential Components of AI Fluency**
- Delegate thoughtfully
- Describe needs clearly  
- Think critically about outputs
- Follow through with care

**Personal AI Collaboration Policy Structure**

**Section 1: Usage Boundaries**
- Define when AI is appropriate (practice, exploration, building understanding)
- Define when to work independently (exams, demonstrating mastery, original thinking)
- Identify professional contexts where AI adds value
- Establish "red lines" = situations where you absolutely will not use AI

**Section 2: Learning Applications**
- AI as tutor/coach, not homework completer
- Maintain ability to explain everything you submit
- Use AI to enhance understanding, not bypass it
- Document specific strategies that work

**Section 3: Transparency Standards**
- When to proactively disclose AI assistance
- How to document AI contributions
- Level of detail to provide
- Handling ambiguous situations

**Section 4: Skill Maintenance**
- Core skills to practice without AI
- Regular "AI-free" work intervals
- Methods to verify continued learning
- Warning signs of over-reliance (and under-utilization)

**Section 5: Ethical Guidelines**
- Accuracy and fact-checking responsibilities
- Respect for others' work and ideas
- Privacy and data considerations
- Broader impacts of AI/computer use

**Section 6: Continuous Growth**
- Staying updated on AI capabilities
- Regular reflection intervals
- Policy adjustment process
- Knowledge sharing with others

**Critical Reflection Questions**
- Is AI engagement helping me grow?
- Am I developing skills needed for my future or just completing tasks?
- Am I being honest about AI's role in my work?
- Am I using AI in ways that align with my values?

**Implementation Guidelines**
- Keep policy realistic given context/constraints
- Make it concise enough to actually reference
- Include creation date and update plans
- Save in multiple accessible places
- Practice applying to real scenarios
- Share and discuss with others for accountability

**Course Completion Elements**
- 4D Framework for thoughtful AI interactions
- AI-augmented learning approach that enhances rather than replaces talent
- AI-augmented career thinking maintaining authenticity
- Personal AI policy reflecting individual values
- Foundation for AI leadership role

**Next Steps**
- Implement policy immediately
- Share learnings with peers
- Add AI Fluency to resume with evidence
- Stay curious about AI developments
- Help shape positive AI use in community
</note>

</notes>
---

- Acknowledgments and license
Copyright 2025 Rick Dakan, Joseph Feller, and Anthropic. Released under the CC BY-NC-SA 4.0 license. This course is based on The AI Fluency Framework by Dakan and Feller.Supported in part by the Higher Education Authority, Ireland, through the National Forum for the Enhancement of Teaching and Learning.
