<context>
# Overview
This PRD develops a comprehensive self-study textbook based on the "AI Fluency for students_KR.md" Korean course. It converts the original video-based course materials into an engaging, single-file Markdown document, providing a complete learning resource for college and graduate students of all majors, including non-IT majors.

The goal is to create an accessible, inclusive, and interactive textbook that promotes AI literacy through practical, real-world applications while maintaining academic rigor and encouraging fun, self-directed learning. All textbook content is written in natural Korean, tailored to Korean culture and university realities.

# Core Features
- **Content Conversion**: Transform video scripts, spoken elements, and course structure into polished, natural narrative textbook prose that flows seamlessly as educational content.
- **Engagement Enhancement**: Use analogies, real-world examples, and interactive elements to make AI concepts fun and approachable, maintaining student interest.
- **Self-Learning Promotion**: Structure the textbook with clear sections, summaries, exercises, thought questions, and activities for independent study.
- **Inclusivity Assurance**: Support students of all backgrounds and abilities with simple language, diverse examples, and accessibility features.
- **Academic Rigor Maintenance**: Cover foundational AI topics comprehensively, encouraging critical thinking while promoting ethical considerations.
- **Korean Content**: All textbook content is written in natural Korean, reflecting Korean university learning environments and AI education trends.

The textbook consists of five main chapters based on previous chapters, including subsections, summaries, and exercises.

### Chapter 1: Introduction to AI Fluency
- **Overview**: Welcome and course introduction.
- **Main Topics**:
  - What is AI Fluency?
  - Why is AI Fluency important for students?
  - Overview of the 4D Framework.
- **Examples**:
  - Healthcare: AI in personalized medicine (e.g., drug discovery).
  - Finance: AI in fraud detection (e.g., Korean bank AI systems).
- **Exercises**: Self-reflection on current AI use, discussion questions.
- **Summary**: Key takeaways and preview of next chapter.

### Chapter 2: The 4D Framework of AI Fluency
- **Overview**: Detailed explanation of delegation, explanation, discernment, and integrity.
- **Main Topics**:
  - Delegation: Identifying tasks for AI and humans.
  - Explanation: Communicating effectively with AI.
  - Discernment: Evaluating AI outputs.
  - Integrity: Ethical and transparent AI use.
- **Examples**:
  - Arts: AI in music composition (e.g., K-pop lyrics generation).
  - Engineering: AI in structural design simulation (e.g., Korean construction AI).
- **Exercises**: Role-playing scenarios, framework application quizzes.
- **Summary**: Interactive diagram explanation and reflection prompts.

### Chapter 3: AI as a Learning Partner
- **Overview**: Using AI to enhance learning without replacing critical thinking.
- **Main Topics**:
  - Distinguishing AI assistance from AI dependency.
  - Setting up AI learning tools.
  - Building a learning journal.
- **Examples**:
  - Humanities: AI in literary analysis (e.g., extracting themes from Korean literature).
  - Science: AI in research data interpretation (e.g., Korean research institute AI).
- **Exercises**: Creating personal learning context documents, journal prompts and practical activities.
- **Summary**: Growth tracking templates and peer discussion ideas.

### Chapter 4: AI in Career Planning
- **Overview**: Leveraging AI for career exploration, skill development, and job seeking.
- **Main Topics**:
  - Career exploration through AI.
  - Skill-building strategies.
  - Job application and interview preparation.
- **Examples**:
  - Business: AI in startup market analysis (e.g., Korean startup AI).
  - Education: AI in curriculum design (e.g., Korean university AI education).
- **Exercises**: Resume workshops, mock interviews, career mapping activities.
- **Summary**: Personal career roadmap templates.

### Chapter 5: Human-Centered AI Use
- **Overview**: Developing personal AI policies and ethical guidelines.
- **Main Topics**:
  - Defining human-centered AI.
  - Creating personal AI collaboration policies.
  - Continuous reflection and growth.
- **Examples**:
  - Healthcare: AI ethics in patient data privacy (e.g., Korean hospital AI).
  - Arts: AI in creative ownership (e.g., Korean artist AI).
- **Exercises**: Policy drafting workshops, ethical dilemma discussions.
- **Summary**: Final reflections and certification quizzes.

### Korean Adaptation and Latest Trends
- **Korean University Context**: Reflects the competitive environment of Korean universities, job preparation, and AI education trends (e.g., government AI education initiatives).
- **Cultural Adaptation**: Includes Korean cultural examples (K-pop, Korean food, Korean companies) to make it relatable.
- **Latest AI Trends (as of October 2025)**:
  - AI Tools: ChatGPT-5, Google Gemini, Naver HyperCLOVA, Kakao AI.
  - Trends: Personalized learning AI, ethical AI regulations (Korean AI ethics guidelines), AI in climate change, multimodal AI (text + image).
  - Examples: Korean companies (Samsung AI in manufacturing, LG AI in smart homes), global (AI in sustainability).

# User Experience
- **Target Audience**:
  - **Primary**: College and graduate students of all majors (e.g., humanities, science, engineering, arts, business, medicine).
  - **Secondary**: Non-IT majors, educators, lifelong learners.
  - **Demographics**: 18-30 years old, diverse cultural and linguistic backgrounds, technical proficiency levels (beginner to intermediate).
  - **Accessibility Needs**: Visual impairment support (descriptive text), non-native speakers (simple language), various learning styles (visual, auditory, kinesthetic through analogies and activities).
- **Design and Accessibility Guidelines**:
  - **Language**: Simple and conversational tone with analogies (e.g., AI as a helpful library assistant).
  - **Structure**: Short sections (5-10 minute reading time), bullet points, headings for scannability.
  - **Visual**: 다이어그램 설명 텍스트 (예: "그림 1: 4D 프레임워크 원, 상호 연결된 기술을 보여줌").
  - **Inclusivity**:
    - Diverse cultural, gender, and field examples.
    - Analogies for non-technical readers (e.g., AI as a problem-solving GPS).
    - Accessibility: High-contrast suggestions, screen reader-friendly format.
  - **Interactivity**: Embedded questions like "Think about it: How would you apply this to your major?"
  - **Length**: Equivalent to 150-200 pages, divided into digestible modules.
</context>
<PRD>
# Technical Architecture
- **Format**: Markdown (.md) for universal compatibility.
- **Tools**: Written in plain text; compatible with Markdown viewers (e.g., GitHub, VS Code).
- **Dependencies**: None; self-contained file.
- **Distribution**: Free download, CC BY-NC-SA license.

### Korean Adaptation and Latest Trends
- **Korean University Context**: Reflects the competitive environment of Korean universities, job preparation, and AI education trends (e.g., government AI education initiatives).
- **Cultural Adaptation**: Includes Korean cultural examples (K-pop, Korean food, Korean companies) to make it relatable.
- **Latest AI Trends (as of October 2025)**:
  - AI Tools: ChatGPT-5, Google Gemini, Naver HyperCLOVA, Kakao AI.
  - Trends: Personalized learning AI, ethical AI regulations (Korean AI ethics guidelines), AI in climate change, multimodal AI (text + image).
  - Examples: Korean companies (Samsung AI in manufacturing, LG AI in smart homes), global (AI in sustainability).

# Development Roadmap
The textbook consists of five main chapters based on previous chapters, including subsections, summaries, and exercises.

### Phase 1: Foundation (Chapters 1-2)
- Convert video scripts and course structure into narrative prose for Chapters 1 and 2.
- Develop analogies, examples, and interactive elements.
- Ensure inclusivity with diverse examples and accessibility features.
- Build MVP: Basic textbook structure with two chapters for initial usability.

### Phase 2: Core Content (Chapters 3-4)
- Expand to Chapters 3 and 4, focusing on learning partnership and career planning.
- Integrate real-world case studies and exercises.
- Add self-assessment quizzes and reflection prompts.

### Phase 3: Advanced Features (Chapter 5)
- Complete Chapter 5 on human-centered AI use.
- Include ethical frameworks, policy development, and final activities.
- Enhance with diagrams, summaries, and certification elements.

### Phase 4: Polish and Distribution
- Review for academic rigor and natural Korean language flow.
- Test for accessibility (WCAG 2.1 compliance).
- Format as single Markdown file and prepare for distribution.

# Logical Dependency Chain
- **Foundation First**: Start with Chapter 1 (Introduction) and Chapter 2 (4D Framework) as they provide the conceptual base.
- **Quick Usable Output**: Aim for a visible front-end like a complete Chapter 1 draft early for testing.
- **Atomic Scoping**: Each chapter is self-contained but builds on the previous (e.g., Chapter 2 references Chapter 1 concepts).
- **Pacing**: Ensure each phase delivers a complete, improvable section without overwhelming complexity.

# Risks and Mitigations
- **Risk**: Content too technical for non-IT students.
  - **Mitigation**: Use analogies, diverse group beta testing.
- **Risk**: Low engagement.
  - **Mitigation**: Interactive elements, real-world examples.
- **Risk**: Ethical concerns in AI examples.
  - **Mitigation**: Emphasize responsible use, diverse perspectives.

### Success Metrics
- **Engagement**: High completion rates in self-study pilots.
- **Feedback**: Positive user surveys on clarity and usefulness.
- **Impact**: Increased AI literacy scores in target audience.
- **Accessibility**: Compliance with WCAG 2.1 guidelines.

# Appendix
This textbook empowers students to navigate the AI era confidently, blending fun learning with practical skills. By transforming source materials into a timeless, accessible resource, it promotes critical thinking and ethical AI engagement across all academic fields.

**Author**: [Your Name]
**Date**: October 23, 2025
**Version**: 1.1
</PRD>