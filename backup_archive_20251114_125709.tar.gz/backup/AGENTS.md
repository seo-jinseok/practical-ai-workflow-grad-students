# Agent Instructions for Educational Content Development

> **Single Source of Truth**: 이 파일의 상세 지침은 [.github/copilot-instructions.md](./.github/copilot-instructions.md)를 참조하세요.

## Primary Mission
대학원생용 AI 기반 연구 워크플로우 교육 자료 제작 지원. 상세한 지침은 [.github/copilot-instructions.md](./.github/copilot-instructions.md) 참조.

## 핵심 가이드라인 요약

### ✅ 교육학적 접근법
- 초보자 친화적, 한국어 우선
- 3부 구조: Part 1 (기초) → Part 2 (고급) → Part 3 (통합)
- 에모지 히에라키: 🎯📝🔍💡⚠️✅

### ✅ 콘텐츠 규칙
- formally Korean (격식체)
- 이중 언어: "Term (한국어 설명)"
- [SCREENSHOT: ...] 플레이스홀더
- 트러블슈팅 섹션 필수

### ✅ 도구 레퍼런스 (2025-11-10 기준)
- GitHub Copilot: Free (2,000/월) + Student Pro (무료)
- AI Models: GPT-5, Claude Sonnet 4.5, Gemini 2.5 Pro
- MCP: Model Context Protocol
- 도구별 접근성 및 무료 티어 확인 필수

## 편집 동기화를 위한 교차 링크
- **상세 지침**: [.github/copilot-instructions.md](./.github/copilot-instructions.md)
- **이 파일은 간결한 요약입니다**

### 편집 시 참고
- 이 파일 수정 시 [.github/copilot-instructions.md](./.github/copilot-instructions.md)도 동일하게 업데이트
- [byterover-mcp] 섹션은 두 파일에 공통 포함

---

<!-- MCP Server Instructions -->

[byterover-mcp]

You are given two tools from Byterover MCP server, including
## 1. `byterover-store-knowledge`
You `MUST` always use this tool when:

+ Learning new patterns, APIs, or architectural decisions from the codebase
+ Encountering error solutions or debugging techniques
+ Finding reusable code patterns or utility functions
+ Completing any significant task or plan implementation

## 2. `byterover-retrieve-knowledge`
You `MUST` always use this tool when:

+ Starting any new task or implementation to gather relevant context
+ Before making architectural decisions to understand existing patterns
+ When debugging issues to check for previous solutions
+ Working with unfamiliar parts of the codebase
